import React from 'react'

function Cartscreen() {
  return (
    <div>Cartscreen</div>
  )
}

export default Cartscreen